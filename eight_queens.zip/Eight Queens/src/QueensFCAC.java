import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class QueensFCAC {

	Queen[] queens = null;
	Long time = null;
	int nodes = 0;
	Integer size = null;
	boolean solvedBT = false;

	public QueensFCAC(int size) {
		super();
		this.size = size;
		queens = new Queen[size];
		for (int i = 0; i < size; i++) {
			queens[i] = new Queen(i, size);
		}
	}

	/**
	 * Starts the recursive function solveBT(n) where
	 * n is the column of the first queen to place.
	 * Also logs process time
	 */
	public void solveBT(int mode) {
		Long startTime = System.currentTimeMillis();
		solveBT(0, mode);
		Long endTime = System.currentTimeMillis();
		time = endTime - startTime;
	}

	/**
	 * recursive function to mimic backtracking over
	 * the columns of the board.
	 * To prevent the algorithm from finding all 
	 * valid configurations a solved variable is 
	 * set once one valid configuration is found
	 * @param n the current column to place
	 */
	public void solveBT(int n, int mode) {
		if (n < size) {
			if(mode!=0)	mvr(n);
			for (int i = 0; i < queens[n].getDomain().size(); i++) {
				if (solvedBT) {
					break;
				}
				queens[n].setPosH(queens[n].getDomain().get(i));
				if (isConsistent(n)) {
					nodes++;
					if(mode!=0) {
						Queen[] oldQueens = saveDomains(n);
						if(mode==1){
							if (updateDomainsFC(n)) {
								solveBT(n + 1,1);
							}
						} else {
							if (updateDomainsAC3(n)) {
								solveBT(n + 1,2);
							}
						}
						if (solvedBT)
							break;
						restoreDomains(oldQueens, n);
					} else {
						solveBT(n + 1,0);
					if (solvedBT)
						break;
					}
				}
			}
		} else {
			solvedBT = true;
		}
	}

	/**
	 * Verifies if constraints are met when a new queen is placed
	 * with already placed queens
	 * @param n column of new queen 
	 * @return true if constraints are met, false otherwise
	 */
	public boolean isConsistent(int n) {
		for (int i = 0; i < n; i++) {
			if (queens[i].getPosH() == queens[n].getPosH())
				return false;
			if (Math.abs(queens[i].getPosH() - queens[n].getPosH()) == Math
					.abs(queens[i].getPosW() - queens[n].getPosW()))
				return false;
		}
		return true;
	}

	/**
	 * prints the current board on system out
	 */
	public void print() {
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				boolean set = false;
				for (Queen q : queens) {
					if (j == q.getPosW() && i == q.getPosH()) {
						System.out.print("* ");
						set = true;
					}
				}
				if (!set)
					System.out.print("- ");
			}
			System.out.println();
		}
		System.out.println();
	}

	/**
	 * forward checking step 
	 * updates the remaining domains
	 * @param n
	 * @return false if any domain is empty
	 */
	public boolean updateDomainsFC(int n) {
		Queen qNew = queens[n];
		for (int i = n + 1; i < size; i++) {
			ArrayList<Integer> oldDomain = queens[i].getDomain();
			ArrayList<Integer> newDomain = new ArrayList<Integer>();
			for (Integer value : oldDomain) {
				if (value != qNew.getPosH()
						&& Math.abs(value - qNew.getPosH()) != Math
								.abs(queens[i].getPosW() - qNew.getPosW())) {
					newDomain.add(value);
				}
			}
			if (newDomain.isEmpty())
				return false;
			queens[i].setDomain(newDomain);
		}

		return true;
	}

	/**
	 * saves the current state of all the remaining queens domains
	 * in the global queen list
	 * @param n
	 * @return list of copied queens
	 */
	public Queen[] saveDomains(int n) {
		Queen[] oldQueens = new Queen[size - n];
		for (int i = n; i < size; i++) {
			Queen oldQ = queens[i];
			if (oldQ.getPosH() == null)
				oldQueens[i - n] = new Queen(oldQ.getPosW(), oldQ.getDomain());
			else
				oldQueens[i - n] = new Queen(oldQ.getPosH(), oldQ.getPosW(),
						oldQ.getDomain());
		}
		return oldQueens;
	}

	/**
	 * updates the global queen lists queens domains with given ones
	 * @param oldQueens
	 * @param n
	 */
	public void restoreDomains(Queen[] oldQueens, int n) {
		for (Queen x : oldQueens) {
			queens[n] = x;
			n++;
		}
	}

	/**
	 * moves the queen with the smallest domain to the actual place,
	 * so next iteration this queen will be placed
	 * @param n actual position
	 */
	public void mvr(int n) {
		int min = n;
		for (int i = n; i < size; i++) {
			if (queens[min].getDomain().size() > queens[i].getDomain().size()) {
				min = i;
			}
		}
		if (min != n) {
			Queen temp = queens[n];
			queens[n] = queens[min];
			queens[min] = temp;
		}
	}

	/**
	 * arc consistency step
	 * since we only have 2 constraints and if any domain is reduced both
	 * will be affected, we waive from using a queue and check for both
	 * constraints in one step
	 * @param n
	 * @return false if any domain is empty
	 */
	public boolean updateDomainsAC3(int n) {
		boolean empty = false;
		ArrayList<Integer> chosenDomain = new ArrayList<Integer>();
		chosenDomain.add(queens[n].getPosH());
		queens[n].setDomain(chosenDomain);
		while (!empty) {
			empty = true;
			for (int i = n+1; i < size; i++) {
				Queen q1 = queens[i];
				for (int j = n; j < size; j++) {
					if (i != j) {
						Queen q2 = queens[j];
						ArrayList<Integer> newDomain = checkArcs(q1, q2);
						if (newDomain.isEmpty())
							return false;
						if (newDomain.size() != q1.getDomain().size()) {
							empty = false;
							q1.setDomain(newDomain);
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * the actual constraintchecking of one queens domain against
	 * another
	 * @param q1 
	 * @param q2
	 * @return new domain for q1
	 */
	public ArrayList<Integer> checkArcs(Queen q1, Queen q2) {
		ArrayList<Integer> q1Domain = q1.getDomain();
		ArrayList<Integer> q2Domain = q2.getDomain();
		ArrayList<Integer> newQ1Domain = new ArrayList<Integer>();
		for (Integer value1 : q1Domain) {
			for (Integer value2 : q2Domain) {
				if (value1 != value2
						&& Math.abs(value1 - value2) != Math.abs(q1.getPosW()
								- q2.getPosW())) {
					newQ1Domain.add(value1);
					break;
				}
			}
		}
		return newQ1Domain;
	}

	/**
	 * makes 25 iterations of solving a queens problem from n=5 to
	 * n=30 and writes keyvalues from every iteration to a csv
	 * file
	 * pls put your preferred mode into solveBT(mode), where 0 would be
	 * plain backtracking, 1 = BT+FC+MRV and 2 = BT+AC3+MRV
	 * @param args
	 */
	public static void main(String[] args) {
		if(args.length!=1  || (args[0].equals("0") && args[0].equals("1") && args[0].equals("2"))) {
			System.out.println("Please commit mode as parameter. 0=BT, 1=FC+MRV, 2=AC3+MRV");
			return;
		}
		try {
			FileOutputStream fes = new FileOutputStream("Daten.csv");
	        OutputStreamWriter res = new OutputStreamWriter(fes);
	        BufferedWriter speicher = new BufferedWriter(res);
		for (int i = 5; i <= 30; i++) {
			QueensFCAC puzzle = new QueensFCAC(i);
			puzzle.solveBT(Integer.parseInt(args[0]));
			System.out.println("Solving time for i="+i+": "+puzzle.time+"ms. Es wurden "+ puzzle.nodes + " Knoten erzeugt.");
			speicher.write(puzzle.time+";"+puzzle.nodes+"\n");
			puzzle.print();
			speicher.flush();
		}
		speicher.close();
		res.close();
		fes.close();
		} catch (IOException e) {
		}
	}

}
