import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class QueensBT {

	Integer[] queens = null;
	int size = 0;
	Long time = null;
	int nodes = 0;
	boolean solvedBT=false;
	

	public QueensBT(int size) {
		super();
		this.size = size;
		queens = new Integer[size];
	}
	
	/**
	 * Starts the recursive function solveBT(n) where
	 * n is the column of the first queen to place.
	 * Also logs process time
	 */
	public void solveBT() {
		Long startTime = System.currentTimeMillis();
        solveBT(0);
        Long endTime = System.currentTimeMillis();
        time = endTime - startTime;
	}
	
	/**
	 * recursive function to mimic backtracking over
	 * the columns of the board.
	 * To prevent the algorithm from finding all 
	 * valid configurations a solved variable is 
	 * set once one valid configuration is found
	 * @param n the current column to place
	 */
	public void solveBT(int n) {
		if(n < size) {
			for (int i = 0; i < size; i++) {
				if(solvedBT){
					break;
				}
				queens[n]=i;
				if(isConsistent(n)) {
					nodes++;
					solveBT(n+1);
				}
			}
		} else {
			solvedBT=true;
		}
	}
	
	/**
	 * Verifies if constraints are met when a new queen is placed
	 * with already placed queens
	 * @param n column of new queen 
	 * @return true if constraints are met, false otherwise
	 */
	public boolean isConsistent(int n) {
		for (int i = 0; i < n; i++) {
			if(queens[i]== queens[n]) 
				return false;
			if(Math.abs(queens[i]-queens[n]) == Math.abs(i-n))
				return false;
		}
		return true;
	}
	
	/**
	 * makes 25 iterations of solving a queens problem from n=5 to
	 * n=30 and writes keyvalues from every iteration to a csv
	 * file
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			FileOutputStream fes = new FileOutputStream("DatenBT.csv");
	        OutputStreamWriter res = new OutputStreamWriter(fes);
	        BufferedWriter speicher = new BufferedWriter(res);
		for (int i = 5; i <= 30; i++) {
			QueensBT puzzle = new QueensBT(i);
			puzzle.solveBT();
			System.out.println("Solving time for i="+i+": "+puzzle.time+"ms. Es wurden "+ puzzle.nodes + " Knoten erzeugt.");
			speicher.write(i+";"+puzzle.time+";"+puzzle.nodes+"\n");
			puzzle.print();
			speicher.flush();
		}
		speicher.close();
		res.close();
		fes.close();
		} catch (Exception e) {
			System.out.println("Lesen/schreiben fehlgeschlagen");
		}
	}
	
	/**
	 * prints the current board on system out
	 */
	public void print() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (i==queens[j]) 
                	System.out.print("* ");
                else           
                	System.out.print("- ");
            }
            System.out.println();
        }  
        System.out.println();
    }
	
}
