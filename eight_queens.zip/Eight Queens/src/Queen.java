import java.util.ArrayList;


public class Queen {
	Integer posH;
	Integer posW;
	ArrayList<Integer> domain;
	
	public Integer getPosH() {
		return posH;
	}

	public void setPosH(Integer posH) {
		this.posH = posH;
	}

	public Integer getPosW() {
		return posW;
	}

	public void setPosW(Integer posW) {
		this.posW = posW;
	}

	public ArrayList<Integer> getDomain() {
		return domain;
	}

	public void setDomain(ArrayList<Integer> domain) {
		this.domain = domain;
	}

	public Queen(int width, int range){
		this.posH = null;
		this.posW = width;
		domain = new ArrayList<Integer>();
		for (int i = 0; i < range; i++) {
			domain.add(i);
		}
	}
	
	public Queen(int height, int width, ArrayList<Integer> domain){
		this.posH = height;
		this.posW = width;
		this.domain = domain;
	}
	
	public Queen(int width, ArrayList<Integer> domain){
		this.posH = null;
		this.posW = width;
		this.domain = domain;
	}
	
	public String toString() {
		return "Queen: H�he: "+posH+" Breite: "+posW + " Domain: "+domain.toString();
	}
	
	public void resetDomains(int range) {
		for (int i = 0; i < range; i++) {
			domain.add(i);
		}
	}
}
